function calcularImc(){
    //entrada
    let p = document.getElementById('peso').value;
    let h = document.getElementById('altura').value;

    //processamento
    let imc = p / (h * h);

    //saida
    document.getElementById('resultado').textContent = 'Seu Imc é de: ' + imc;
}