// 
// aceitar palpite
// negar valores negativos 
// max. de tentativas
//  
const rng = (parseInt(Math.random()* 101)+1);
console.log ('numero gerado', rng);
//
let tentativas = 0;
const limite= 10;
//
function tentativa(){
  const valor = document.getElementById("entrada").value;
    //
    if (tentativas==limite){
      document.getElementById("resposta").textContent= 'Você atingiu o limite de tentativas'
      return;
    }
      tentativas++;
  // botao de tentativa e acerto 
    if(valor>rng){
      document.getElementById("resposta").textContent='O valor ultrapassa o valor gerado';
      console.log("acima")
    }
    if(valor<rng){
      document.getElementById("resposta").textContent='O valor está abaixo do valor gerado';
      console.log("abaixo")
    }if(valor==rng){
    document.getElementById('resposta').textContent='Parabens você acertou o valor gerado';
    console.log("otimo")
    }
}

  

